n=int(input("enter a number:"))
if(n%4)==0:
    print("this is leap year")
elif n!=(n%4):
    print("this is not a leap year") 
else:
    print("you have enter wrong input")